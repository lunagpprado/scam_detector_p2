import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import pickle
import re
import os

class SpamDetectorML:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=3000, stop_words='english')
        self.naive_bayes = MultinomialNB()
        self.decision_tree = DecisionTreeClassifier(max_depth=20, random_state=42)
        self.is_trained = False
        
    def clean_text(self, text):
        """Clean and preprocess text data"""
        if pd.isna(text):
            return ""
        
        # Convert to string and lowercase
        text = str(text).lower()
        
        # Remove URLs
        text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
        
        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        return text
    
    def prepare_data(self, csv_files):
        """Load and prepare data from multiple CSV files"""
        print("Loading datasets...")
        all_data = []
        
        for csv_file in csv_files:
            if os.path.exists(csv_file):
                try:
                    df = pd.read_csv(csv_file, encoding='latin-1')
                    print(f"Loaded {csv_file}: {len(df)} emails")
                    all_data.append(df)
                except Exception as e:
                    print(f"Error loading {csv_file}: {e}")
        
        if not all_data:
            raise ValueError("No data could be loaded from the provided files")
        
        # Combine all datasets
        combined_df = pd.concat(all_data, ignore_index=True)
        print(f"\nTotal emails loaded: {len(combined_df)}")
        
        # Create combined text from subject and body
        combined_df['text'] = combined_df.apply(
            lambda row: self.clean_text(str(row.get('subject', '')) + ' ' + str(row.get('body', ''))), 
            axis=1
        )
        
        # Get labels (1 = spam, 0 = ham)
        combined_df['label'] = combined_df['label'].astype(int)
        
        # Remove empty texts
        combined_df = combined_df[combined_df['text'].str.strip() != '']
        
        print(f"After cleaning: {len(combined_df)} emails")
        print(f"Spam emails: {combined_df['label'].sum()}")
        print(f"Ham emails: {len(combined_df) - combined_df['label'].sum()}")
        
        return combined_df['text'].values, combined_df['label'].values
    
    def train(self, csv_files, test_size=0.2):
        """Train both models on the provided datasets"""
        print("\n" + "="*60)
        print("TRAINING SPAM DETECTION MODELS")
        print("="*60)
        
        # Prepare data
        X, y = self.prepare_data(csv_files)
        
        # Split data
        print("\nSplitting data into training and testing sets...")
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42, stratify=y
        )
        
        print(f"Training set: {len(X_train)} emails")
        print(f"Testing set: {len(X_test)} emails")
        
        # Vectorize text
        print("\nConverting text to numerical features...")
        X_train_vec = self.vectorizer.fit_transform(X_train)
        X_test_vec = self.vectorizer.transform(X_test)
        
        # Train Naive Bayes
        print("\n" + "-"*60)
        print("Training Naive Bayes Classifier...")
        print("-"*60)
        self.naive_bayes.fit(X_train_vec, y_train)
        nb_predictions = self.naive_bayes.predict(X_test_vec)
        nb_accuracy = accuracy_score(y_test, nb_predictions)
        print(f"Naive Bayes Accuracy: {nb_accuracy*100:.2f}%")
        
        # Train Decision Tree
        print("\n" + "-"*60)
        print("Training Decision Tree Classifier...")
        print("-"*60)
        self.decision_tree.fit(X_train_vec, y_train)
        dt_predictions = self.decision_tree.predict(X_test_vec)
        dt_accuracy = accuracy_score(y_test, dt_predictions)
        print(f"Decision Tree Accuracy: {dt_accuracy*100:.2f}%")
        
        # Print detailed reports
        print("\n" + "="*60)
        print("NAIVE BAYES - DETAILED REPORT")
        print("="*60)
        print(classification_report(y_test, nb_predictions, 
                                   target_names=['Ham', 'Spam']))
        
        print("\n" + "="*60)
        print("DECISION TREE - DETAILED REPORT")
        print("="*60)
        print(classification_report(y_test, dt_predictions, 
                                   target_names=['Ham', 'Spam']))
        
        self.is_trained = True
        print("\n" + "="*60)
        print("TRAINING COMPLETED SUCCESSFULLY!")
        print("="*60)
        
        return {
            'naive_bayes_accuracy': nb_accuracy,
            'decision_tree_accuracy': dt_accuracy
        }
    
    def predict(self, sender, subject, body, primary_algo="Naive Bayes", secondary_algo="Decision Tree"):
        """Predict if an email is spam using the selected algorithms"""
        if not self.is_trained:
            raise ValueError("Models must be trained before prediction. Call train() first.")
        
        # Combine and clean text
        text = self.clean_text(subject + ' ' + body)
        
        # Vectorize
        text_vec = self.vectorizer.transform([text])
        
        # Get predictions from both models
        nb_proba = self.naive_bayes.predict_proba(text_vec)[0][1] * 100  
        dt_proba = self.decision_tree.predict_proba(text_vec)[0][1] * 100  
        
        # Determine which algorithm to use as primary
        algo_map = {
            "Naive Bayes": nb_proba,
            "Decision Tree": dt_proba,
            "Support Vector Machine (SVM)": (nb_proba + dt_proba) / 2, 
            "Random Forest": (nb_proba + dt_proba) / 2,
            "Logistic Regression": (nb_proba + dt_proba) / 2,
            "Neural Network": (nb_proba + dt_proba) / 2
        }
        
        primary_score = algo_map.get(primary_algo, nb_proba)
        secondary_score = algo_map.get(secondary_algo, dt_proba)
        
        # Weighted average: 70% primary, 30% secondary
        final_probability = (primary_score * 0.7) + (secondary_score * 0.3)
        
        return {
            'spam_probability': final_probability,
            'naive_bayes_score': nb_proba,
            'decision_tree_score': dt_proba,
            'primary_score': primary_score,
            'secondary_score': secondary_score
        }
    
    def save_models(self, filepath='spam_detector_models.pkl'):
        """Save trained models to disk"""
        if not self.is_trained:
            raise ValueError("Models must be trained before saving")
        
        model_data = {
            'vectorizer': self.vectorizer,
            'naive_bayes': self.naive_bayes,
            'decision_tree': self.decision_tree,
            'is_trained': self.is_trained
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)
        
        print(f"\nModels saved to {filepath}")
    
    def load_models(self, filepath='spam_detector_models.pkl'):
        """Load trained models from disk"""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model file not found: {filepath}")
        
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)
        
        self.vectorizer = model_data['vectorizer']
        self.naive_bayes = model_data['naive_bayes']
        self.decision_tree = model_data['decision_tree']
        self.is_trained = model_data['is_trained']
        
        print(f"Models loaded from {filepath}")


def train_and_save_models():
    """Utility function to train and save models"""
    # List of CSV files to train on
    csv_files = [
        'CEAS_08.csv',
        'SpamAssasin.csv',
        'Nazario.csv',
        'Nigerian_Fraud.csv'
    ]
    
    # Create and train the detector
    detector = SpamDetectorML()
    results = detector.train(csv_files)
    
    # Save the trained models
    detector.save_models('spam_detector_models.pkl')
    
    return detector, results


if __name__ == "__main__":
    # Train the models when this script is run directly
    detector, results = train_and_save_models()
    
    # Test with a sample email
    print("\n" + "="*60)
    print("TESTING WITH SAMPLE EMAIL")
    print("="*60)
    
    test_subject = "URGENT: You've won $1,000,000! Click here now!"
    test_body = "Congratulations! You have been selected to receive one million dollars. Click this link immediately to claim your prize. This offer expires soon!"
    
    result = detector.predict("", test_subject, test_body)
    print(f"\nTest Email Subject: {test_subject}")
    print(f"Spam Probability: {result['spam_probability']:.2f}%")
    print(f"Naive Bayes Score: {result['naive_bayes_score']:.2f}%")
    print(f"Decision Tree Score: {result['decision_tree_score']:.2f}%")
